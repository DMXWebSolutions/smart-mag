<p>
	<?php _e('You can use SiteOrigin Page Builder to create home and sub pages, filled your own widgets.', 'so-panels') ?>
	<?php _e('The page layouts are responsive and fully customizable.', 'so-panels') ?>
</p>
<p>
	<?php printf( __( "Read the <a href='%s' target='_blank'>full documentation</a> on SiteOrigin.", 'so-panels' ), 'http://siteorigin.com/page-builder/documentation/' ) ?>
</p>